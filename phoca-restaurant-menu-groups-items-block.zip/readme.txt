=== Phoca Restaurant Menu Groups Items Block ===
Contributors:      Jan Pavelka - https://www.phoca.cz
Tags:              block
Tested up to:      6.1
Stable tag:        6.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Phoca Restaurant Menu Groups Items Block is part of parent blocks such as:

- Phoca Restaurant Menu Daily Menu Block
- Phoca Restaurant Menu Beverage List Block

It adds the ability to specify groups and items for the parent blocks.

For more information, see <a href="https://www.phoca.cz" target="_blank">Phoca documentation website</a>
or ask question in <a href="https://www.phoca.cz" target="_blank">Phoca Forum</a>.

== Installation ==


1. Upload the plugin files to the `/wp-content/plugins/phoca-restaurant-menu-groups-items-block` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Don't forget to install some parent block of this block.


== Frequently Asked Questions ==



== Screenshots ==

1. screenshot-1.png

== Changelog ==

= 6.0.0 =
* Release

== Arbitrary section ==


